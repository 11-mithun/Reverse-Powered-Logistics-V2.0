import axios from 'axios'

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000'

export const api = axios.create({
  baseURL: API_URL,
  headers: { 'Content-Type': 'application/json' },
})

api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('rl_token')
    if (token) config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('rl_token')
      localStorage.removeItem('rl_user')
      if (!window.location.pathname.includes('/login')) window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

// Auth
export const authApi = {
  login: (email: string, password: string) => api.post('/api/auth/login', { email, password }),
  register: (email: string, name: string, password: string) => api.post('/api/auth/register', { email, name, password }),
  me: () => api.get('/api/auth/me'),
}

// Returns
export const returnsApi = {
  list: (params?: any) => api.get('/api/returns', { params }),
  get: (id: string) => api.get(`/api/returns/${id}`),
  create: (data: any) => api.post('/api/returns', data),
  update: (id: string, data: any) => api.patch(`/api/returns/${id}`, data),
  stats: () => api.get('/api/returns/stats/summary'),
  batch: (file: File) => {
    const fd = new FormData(); fd.append('file', file)
    return api.post('/api/returns/batch', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
}

// Analytics
export const analyticsApi = {
  kpis: () => api.get('/api/analytics/kpis'),
  heatmap: () => api.get('/api/analytics/heatmap'),
  daily: (days = 30) => api.get(`/api/analytics/daily?days=${days}`),
  seasonal: () => api.get('/api/analytics/seasonal'),
  forecast: () => api.get('/api/analytics/forecast'),
  suppliers: () => api.get('/api/analytics/suppliers'),
  productRisk: () => api.get('/api/analytics/products/risk'),
  benchmarks: () => api.get('/api/analytics/benchmarks'),
  circular: () => api.get('/api/analytics/circular'),
}

// Marketplace
export const marketplaceApi = {
  list: (type?: string) => api.get('/api/marketplace', { params: { type } }),
  quote: (id: string, data: any) => api.post(`/api/marketplace/${id}/quote`, data),
}

// Routing
export const routingApi = {
  suggest: (data: any) => api.post('/api/routing/suggest', data),
  warehouses: () => api.get('/api/routing/warehouses'),
}

// Integrations
export const integrationsApi = {
  list: () => api.get('/api/integrations'),
  connect: (platform: string) => api.post('/api/integrations/connect', { platform }),
  disconnect: (platform: string) => api.post('/api/integrations/disconnect', { platform }),
}

// SLA
export const slaApi = {
  queue: () => api.get('/api/sla/queue'),
  escalate: (id: string) => api.post(`/api/sla/escalate/${id}`),
}

// Customer portal (no auth)
export const portalApi = {
  submit: (data: any) => api.post('/api/customers/portal/submit', data),
  track: (id: string) => api.get(`/api/customers/portal/track/${id}`),
}

export default api

// Agents
export const agentsApi = {
  runPipeline: (data: any) => api.post('/api/agents/run', data),
  communicationLog: (limit = 50) => api.get(`/api/agents/communication-log?limit=${limit}`),
  marketDashboard: () => api.get('/api/agents/market/dashboard'),
  inventoryHealth: () => api.get('/api/agents/inventory/health'),
  stockLevels: (sku: string, category: string) => api.get(`/api/agents/inventory/stock?sku=${sku}&category=${category}`),
  generateSynthetic: (data: any) => api.post('/api/agents/synthetic/generate', data),
  syntheticStats: () => api.get('/api/agents/synthetic/stats'),
  carbonOffset: () => api.get('/api/agents/carbon-offset'),
  nrvHeatmap: () => api.get('/api/agents/nrv-heatmap'),
}

// Premium Features
export const premiumApi = {
  cognitiveProcurement: (data: any) => api.post('/api/premium/cognitive-procurement', data),
  hyperDisposition: (data: any) => api.post('/api/premium/hyper-disposition', data),
  slaBreachAction: (data: any) => api.post('/api/premium/sla-breach-action', data),
  createAuction: (data: any) => api.post('/api/premium/auction/create', data),
  getAuction: (id: string) => api.get(`/api/premium/auction/${id}`),
  listAuctions: () => api.get('/api/premium/auction/list'),
  languages: () => api.get('/api/premium/i18n/languages'),
  translate: (lang: string) => api.get(`/api/premium/i18n/translate?lang=${lang}`),
  clvAutoApprove: (data: any) => api.post('/api/premium/clv-auto-approve', data),
  supplierScorecard: () => api.get('/api/premium/suppliers/scorecard'),
  insurancePlans: (price: number) => api.get(`/api/premium/insurance/plans?product_price=${price}`),
  fileClaim: (data: any) => api.post('/api/premium/insurance/claim', data),
  optimize3pl: (data: any, apiKey: string) => api.post('/api/premium/3pl/optimize', data, { headers: {'X-API-Key': apiKey} }),
  generateApiKey: () => api.post('/api/premium/3pl/api-key/generate'),
  kanbanItems: () => api.get('/api/premium/kanban/items'),
  kanbanMove: (return_id: string, new_status: string) => api.post('/api/premium/kanban/move', { return_id, new_status }),
}
