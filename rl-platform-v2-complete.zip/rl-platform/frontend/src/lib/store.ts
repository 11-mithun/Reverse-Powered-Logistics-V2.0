import { create } from 'zustand'

interface User { id: string; email: string; name: string; role: string }
interface AuthStore {
  user: User | null
  token: string | null
  setAuth: (user: User, token: string) => void
  logout: () => void
  init: () => void
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  token: null,
  setAuth: (user, token) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('rl_token', token)
      localStorage.setItem('rl_user', JSON.stringify(user))
    }
    set({ user, token })
  },
  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('rl_token')
      localStorage.removeItem('rl_user')
    }
    set({ user: null, token: null })
    window.location.href = '/login'
  },
  init: () => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('rl_token')
      const userStr = localStorage.getItem('rl_user')
      if (token && userStr) {
        try { set({ token, user: JSON.parse(userStr) }) } catch {}
      }
    }
  },
}))
